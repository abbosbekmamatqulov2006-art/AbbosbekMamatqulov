from flask import Flask, render_template, request, jsonify, session
from datetime import datetime
import os

app = Flask(__name__)
app.secret_key = "bankomat-secret-2024"

# --- Boshlang'ich ma'lumotlar ---
DEFAULT_BALANCE = 20_000_000
DEFAULT_PIN = "1234"

def get_state():
    if "balance" not in session:
        session["balance"] = DEFAULT_BALANCE
    if "pin" not in session:
        session["pin"] = DEFAULT_PIN
    if "history" not in session:
        session["history"] = []
    if "attempts" not in session:
        session["attempts"] = 0
    return session

def now():
    return datetime.now().strftime("%d.%m.%Y %H:%M")

# --- Sahifalar ---
@app.route("/")
def index():
    return render_template("index.html")

# --- API ---
@app.route("/api/login", methods=["POST"])
def login():
    state = get_state()
    data = request.json
    entered = data.get("pin", "")

    if state["attempts"] >= 3:
        return jsonify({"ok": False, "blocked": True, "msg": "Karta bloklandi!"})

    if entered == state["pin"]:
        session["attempts"] = 0
        return jsonify({"ok": True})
    else:
        session["attempts"] = state["attempts"] + 1
        left = 3 - session["attempts"]
        if left <= 0:
            return jsonify({"ok": False, "blocked": True, "msg": "Karta bloklandi! Bank bilan bog'laning."})
        return jsonify({"ok": False, "msg": f"Noto'g'ri PIN! Qoldi: {left} urinish"})

@app.route("/api/balance", methods=["GET"])
def balance():
    state = get_state()
    return jsonify({"balance": state["balance"], "time": now()})

@app.route("/api/withdraw", methods=["POST"])
def withdraw():
    state = get_state()
    data = request.json
    try:
        amount = int(data.get("amount", 0))
    except (ValueError, TypeError):
        return jsonify({"ok": False, "msg": "Noto'g'ri miqdor kiritildi"})

    if amount <= 0:
        return jsonify({"ok": False, "msg": "Musbat miqdor kiriting"})
    if amount % 1000 != 0:
        return jsonify({"ok": False, "msg": "Faqat 1000 ga karrali miqdor yechsa bo'ladi"})
    if amount > state["balance"]:
        return jsonify({"ok": False, "msg": "Yetarli mablag' mavjud emas"})

    session["balance"] = state["balance"] - amount
    tx = {"tur": "Yechish", "miqdor": -amount, "vaqt": now(), "qoldiq": session["balance"]}
    session["history"] = [tx] + state["history"]
    session.modified = True
    return jsonify({"ok": True, "balance": session["balance"], "msg": f"{amount:,} so'm muvaffaqiyatli yechildi"})

@app.route("/api/deposit", methods=["POST"])
def deposit():
    state = get_state()
    data = request.json
    try:
        amount = int(data.get("amount", 0))
    except (ValueError, TypeError):
        return jsonify({"ok": False, "msg": "Noto'g'ri miqdor kiritildi"})

    if amount <= 0:
        return jsonify({"ok": False, "msg": "Musbat miqdor kiriting"})

    session["balance"] = state["balance"] + amount
    tx = {"tur": "Kirim", "miqdor": amount, "vaqt": now(), "qoldiq": session["balance"]}
    session["history"] = [tx] + state["history"]
    session.modified = True
    return jsonify({"ok": True, "balance": session["balance"], "msg": f"{amount:,} so'm muvaffaqiyatli qo'yildi"})

@app.route("/api/change_pin", methods=["POST"])
def change_pin():
    state = get_state()
    data = request.json
    old = data.get("old_pin", "")
    new = data.get("new_pin", "")
    confirm = data.get("confirm_pin", "")

    if old != state["pin"]:
        return jsonify({"ok": False, "msg": "Joriy PIN noto'g'ri"})
    if len(new) != 4 or not new.isdigit():
        return jsonify({"ok": False, "msg": "PIN 4 ta raqamdan iborat bo'lishi kerak"})
    if new == old:
        return jsonify({"ok": False, "msg": "Yangi PIN eski bilan bir xil bo'lmasin"})
    if new != confirm:
        return jsonify({"ok": False, "msg": "PIN lar mos kelmadi"})

    session["pin"] = new
    return jsonify({"ok": True, "msg": "PIN muvaffaqiyatli o'zgartirildi"})

@app.route("/api/history", methods=["GET"])
def history():
    state = get_state()
    return jsonify({"history": state["history"]})

@app.route("/api/logout", methods=["POST"])
def logout():
    session.clear()
    return jsonify({"ok": True})

if __name__ == "__main__":
    app.run(debug=True)
