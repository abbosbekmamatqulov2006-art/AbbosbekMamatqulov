# 🏧 Supper Bank ATM — Flask ilovasi

## Ishga tushirish

### 1. Kerakli kutubxonalarni o'rnatish
```
pip install -r requirements.txt
```

### 2. Dasturni ishga tushirish
```
python app.py
```

### 3. Brauzerda ochish
```
http://localhost:5000
```

---

## Kirish ma'lumotlari
- **PIN:** `1234`
- **Boshlang'ich balans:** 20,000,000 so'm

---

## Papka tuzilmasi
```
bankomat/
├── app.py              ← Flask backend
├── requirements.txt    ← Kerakli kutubxonalar
├── README.md
└── templates/
    └── index.html      ← Frontend UI
```

---

## Imkoniyatlar
- PIN bilan kirish (3 marta xato → bloklash)
- Balansni ko'rish
- Pul yechish (tez miqdor tugmalari bilan)
- Pul qo'yish
- PIN almashtirish
- Amallar tarixi
